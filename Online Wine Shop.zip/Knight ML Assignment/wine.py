#importing the dataset
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#reading the files or data
dataset = pd.read_csv('train.csv')
dataset1 = pd.read_csv('test.csv')
X_train = dataset.iloc[:, [1,4,5,6,7,8,9,10]].values
y_train = dataset.iloc[:, -1].values
X_test = dataset1.iloc[:, [1,4,5,6,7,8,9,10]].values

#Dealing with missing values
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(missing_values = np.nan, strategy = 'mean')
X_train[:, 3:4] = imputer.fit_transform(X_train[:, 3:4])
X_test[:, 3:4] = imputer.fit_transform(X_test[:, 3:4])

imputer1 = SimpleImputer(missing_values = np.nan, strategy = 'most_frequent')
X_train[:, [0,1,4,5,6,7]] = imputer1.fit_transform(X_train[:, [0,1,4,5,6,7]])
X_test[:,  [0,1,4,5,6,7]] = imputer1.fit_transform(X_test[:, [0,1,4,5,6,7]])


# Encoding categorical data
# Encoding the Independent Variable
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
X_train[:, 0] = le.fit_transform(X_train[:, 0])
X_test[:, 0] = le.fit_transform(X_test[:, 0])
X_train[:, 1] = le.fit_transform(X_train[:, 1])
X_test[:, 1] = le.fit_transform(X_test[:, 1])
X_train[:, 4] = le.fit_transform(X_train[:, 4])
X_test[:, 4] = le.fit_transform(X_test[:, 4])
X_train[:, 5] = le.fit_transform(X_train[:, 5])
X_test[:, 5] = le.fit_transform(X_test[:, 5])
X_train[:, 6] = le.fit_transform(X_train[:, 6])
X_test[:, 6] = le.fit_transform(X_test[:, 6])
X_train[:, 7] = le.fit_transform(X_train[:, 7])
X_test[:, 7] = le.fit_transform(X_test[:, 7])


# Applying PCA
from sklearn.decomposition import PCA
pca = PCA(n_components = 2)
X_train = pca.fit_transform(X_train)
X_test = pca.transform(X_test)
explained_variance = pca.explained_variance_ratio_

# Training the Random Forest Classification model on the Training set
from sklearn.ensemble import RandomForestClassifier
cl = RandomForestClassifier(n_estimators = 100, criterion = 'entropy', max_features = 'auto' ,
                            n_jobs = -1, oob_score =True , random_state = 0)
cl.fit(X_train, y_train)

#make predictions
y_pred = cl.predict(X_test)
X_pred = cl.predict(X_train) 

# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_train, X_pred)
print(cm)

# accuracy = (77839/82657) * 100 = 94.17

#visualising the training data
#univaraite Analysis
dataset['variety'].value_counts().plot.bar()
#Bivaraite Analysis
dataset.groupby('variety')["price"].mean().plot.bar()
dataset.plot.scatter('points','price')
dataset.corr()
viz = pd.crosstab(dataset['variety'],dataset['region_1'])


#DataFrame
submission = pd.DataFrame({'variety' : y_pred})

#Converting to csv file
filename = 'Variety Predictions.csv'
submission.to_csv(filename, index = False)
print('Saved File; ' + filename)